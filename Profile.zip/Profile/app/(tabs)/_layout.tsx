import { Feather, FontAwesome, FontAwesome5, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import React from 'react';
import {
  Dimensions,
  Image,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

const { width } = Dimensions.get('window');

const COLORS = {
  background: '#121212', // A very dark gray, almost black
  surface: '#1E1E1E',   // Slightly lighter gray for cards/sections
  primaryText: '#FFFFFF',
  secondaryText: '#A0A0A0',
  accentGreen: '#39FF14', // A vibrant green, adjust if needed
  separator: '#333333',
  iconColor: '#A0A0A0',
};

const App = () => {
  const avatarUrl = 'https://randomuser.me/api/portraits/men/32.jpg'; // Replace with your image

  const ListItem = ({ icon, iconSet, label, value, valueColor, subLabel, isBoldValue = false }) => {
    // Map iconSet string to the actual icon component
    const iconComponents = {
      FontAwesome,
      FontAwesome5,
      Feather,
      Ionicons,
      MaterialCommunityIcons,
    };
    const IconComponent = iconSet ? iconComponents[iconSet] : null;

    return (
      <TouchableOpacity style={styles.listItemContainer} activeOpacity={0.7}>
        <View style={styles.listItemLeft}>
          {IconComponent && icon && (
            <IconComponent name={icon} size={20} color={COLORS.iconColor} style={styles.listItemIcon} />
          )}
          <View>
            <Text style={styles.listItemLabel}>{label}</Text>
            {subLabel && <Text style={styles.listItemSubLabel}>{subLabel}</Text>}
          </View>
        </View>
        <View style={styles.listItemRight}>
          {value && (
            <Text
              style={[
                styles.listItemValue,
                { color: valueColor || COLORS.primaryText, fontWeight: isBoldValue ? 'bold' : 'normal' },
              ]}
            >
              {value}
            </Text>
          )}
          <Ionicons name="chevron-forward" size={20} color={COLORS.iconColor} />
        </View>
      </TouchableOpacity>
    );
  };

  const SectionHeader = ({ title }) => (
    <Text style={styles.sectionHeader}>{title}</Text>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
        <TouchableOpacity>
          <Ionicons name="arrow-back" size={22} color={COLORS.primaryText} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Profile</Text>
        </View>
        <TouchableOpacity style={styles.supportButton}>
          <MaterialCommunityIcons name="chat-processing-outline" size={18} color={COLORS.primaryText} style={{ marginRight: 5 }} />
          <Text style={styles.supportButtonText}>support</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} >
        <View style={styles.profileInfoContainer}>
          <View style={styles.profileDetails}>
            <Image source={{ uri: avatarUrl }} style={styles.avatar} />
            <View style={styles.profileTextContainer}>
              <Text style={styles.profileName}>andaz Kumar</Text>
              <Text style={styles.profileMemberSince}>member since Dec, 2020</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.editIconContainer}>
            <Feather name="edit-2" size={20} color={COLORS.primaryText} />
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.credGarageBanner} activeOpacity={0.8}>
          <View style={styles.garageIconContainer}>
            <FontAwesome5 name="car-side" size={24} color={COLORS.primaryText} />
          </View>
          <View style={styles.garageTextContainer}>
            <Text style={styles.garageMainText}>get to know your vehicles, inside out</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={styles.garageSubText}>CRED garage</Text>
              <Ionicons name="arrow-forward" size={18} color={COLORS.primaryText} style={{ marginLeft: 8 }} />
            </View>
          </View>
        </TouchableOpacity>

        <View style={styles.infoSection}>
          {/* Custom rendering for refresh available */}
          <View style={styles.listItemContainer}>
            <View style={styles.listItemLeft}>
              <MaterialCommunityIcons name="speedometer" size={20} color={COLORS.iconColor} style={styles.listItemIcon} />
              <Text style={styles.listItemLabel}>
                credit score <Text style={styles.dotSeparator}>•</Text>{' '}
                <Text style={styles.refreshAvailable}>REFRESH AVAILABLE</Text>
              </Text>
            </View>
            <TouchableOpacity style={styles.listItemRight} onPress={() => console.log('Credit Score pressed')}>
              <Text style={[styles.listItemValue, { color: COLORS.primaryText }]}>757</Text>
              <Ionicons name="chevron-forward" size={20} color={COLORS.iconColor} />
            </TouchableOpacity>
          </View>

          <View style={styles.separator} />
          <ListItem
            icon="rupee"
            iconSet="FontAwesome"
            label="lifetime cashback"
            value="₹3"
          />
          <View style={styles.separator} />
          <ListItem
            icon="bank-outline"
            iconSet="MaterialCommunityIcons"
            label="bank balance"
            value="check"
          />
        </View>
        <View style={styles.benefitsSection}>
          <SectionHeader title="YOUR REWARDS & BENEFITS" />
          <View style={styles.rewardsSection}>
            <ListItem
              label="cashback balance"
              subLabel="₹0"
            />
            <View style={styles.separator} />
            <ListItem
              label="coins"
              subLabel="26,46,583"
            />
            <View style={styles.separator} />
            <ListItem
              label="win upto Rs 1000"
              subLabel="refer and earn"
            />
          </View>

          <SectionHeader title="TRANSACTIONS & SUPPORT" />
          <View style={styles.transactionsSection}>
            <ListItem
              label="all transactions"
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 12,
    backgroundColor: COLORS.surface, // Header can have same bg or slightly different
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primaryText,
     marginLeft: 10,
  },
  supportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: COLORS.secondaryText,
  },
  supportButtonText: {
    color: COLORS.primaryText,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  profileInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: COLORS.surface, // Match the theme
  },
  profileDetails: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 15,
  },
  profileTextContainer: {
    // No specific styles needed here if children handle their own
  },
  profileName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primaryText,
  },
  profileMemberSince: {
    fontSize: 14,
    color: COLORS.secondaryText,
    marginTop: 2,
  },
  editIconContainer: {
    padding: 8, // Make it easier to tap
    borderRadius: 20, // Circular background for the icon
    borderWidth: 1,
    borderColor: COLORS.secondaryText,
  },
  credGarageBanner: {
    flexDirection: 'row',
    backgroundColor: COLORS.background,
    marginHorizontal: 15,
    borderWidth: 0.3,
    borderColor: COLORS.secondaryText,
    padding: 15,
    alignItems: 'center',
    marginBottom: 20,
  },
  garageIconContainer: {
    backgroundColor: '#2A2A2A', // Slightly different shade for icon background
    padding: 12,
    borderRadius: 25, // Make it circular
    marginRight: 15,
  },
  garageTextContainer: {
    flex: 1,
  },
  garageMainText: {
    fontSize: 12,
    color: COLORS.secondaryText,
    marginBottom: 5,
  },
  garageSubText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: COLORS.primaryText,
  },
  infoSection: {
    marginHorizontal: 15,
    backgroundColor: COLORS.surface,
    borderRadius: 10,
    overflow: 'hidden', // To clip children with border radius
    marginBottom: 25,
  },
  benefitsSection: {

    backgroundColor: COLORS.background,

  },
  rewardsSection: {
    marginHorizontal: 15,
    backgroundColor: COLORS.background,
    borderRadius: 10,
    overflow: 'hidden',
    marginBottom: 25,
  },
  transactionsSection: {
    marginHorizontal: 15,
    backgroundColor: COLORS.background,
    borderRadius: 10,
    overflow: 'hidden',
    marginBottom: 25,
  },
  listItemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 15,
  },
  listItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  listItemIcon: {
    marginRight: 15,
  },
  listItemLabel: {
    fontSize: 15,
    color: COLORS.primaryText,
  },
  listItemSubLabel: {
    fontSize: 12,
    color: COLORS.secondaryText,
    marginTop: 2,
  },
  listItemRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  listItemValue: {
    fontSize: 15,
    color: COLORS.primaryText,
    marginRight: 8,
  },
  separator: {
    height: 1,
    backgroundColor: COLORS.separator,
    marginLeft: 15, // To not extend full width if icon is present, or 0 for full width
  },
  sectionHeader: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.secondaryText,
    marginHorizontal: 20,
    marginBottom: 10,
    marginTop: 10, // Space before section header
    letterSpacing: 2,
  },
  dotSeparator: {
    color: COLORS.secondaryText,
    marginHorizontal: 4,
  },
  refreshAvailable: {
    color: COLORS.accentGreen,
    fontSize: 13,
    fontWeight: 'bold',
  },
});

export default App;